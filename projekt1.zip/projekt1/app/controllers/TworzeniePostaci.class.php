<?php

namespace app\controllers;
use core\App;

class TworzeniePostaci {

    public function action_postac() {
        App::getSmarty()->display("postac_widok.tpl");
  }  
}
