<?php

namespace app\controllers;
use core\App;

class TworzenieNPC {

    public function action_npc() {
        App::getSmarty()->display("npc_widok.tpl");
  }  
}
