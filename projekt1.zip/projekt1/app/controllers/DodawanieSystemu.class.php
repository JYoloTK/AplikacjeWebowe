<?php

namespace app\controllers;
use core\App;

class DodawanieSystemu {

    public function action_system() {
        App::getSmarty()->display("system_widok.tpl");
  }  
}
