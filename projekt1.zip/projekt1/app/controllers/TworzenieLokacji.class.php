<?php

namespace app\controllers;
use core\App;

class TworzenieLokacji {

    public function action_lokacja() {
        App::getSmarty()->display("lokacja_widok.tpl");
  }  
}
