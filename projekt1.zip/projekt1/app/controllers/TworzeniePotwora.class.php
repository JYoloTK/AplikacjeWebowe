<?php

namespace app\controllers;
use core\App;

class TworzeniePotwora {

    public function action_potwor() {
        App::getSmarty()->display("potwor_widok.tpl");
  }  
}
