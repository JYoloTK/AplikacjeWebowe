<?php

namespace app\controllers;

use core\App;


class PrzykladAkcji {

    public function action_przyklad(){
    App::getSmarty()->display("przyklad_widok.tpl");
    }
}
