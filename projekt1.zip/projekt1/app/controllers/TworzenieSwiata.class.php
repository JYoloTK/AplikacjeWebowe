<?php

namespace app\controllers;
use core\App;

class TworzenieSwiata {

    public function action_swiat() {
        App::getSmarty()->display("swiat_widok.tpl");
  }  
}
