<?php
/* Smarty version 4.1.0, created on 2022-05-17 09:09:10
  from 'C:\xampp\Nowy folder\htdocs\projekt1\app\views\system_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62834a16adb3c2_05788572',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b87d439ff9bd6e455de1f0774b47c8f0daf957ba' => 
    array (
      0 => 'C:\\xampp\\Nowy folder\\htdocs\\projekt1\\app\\views\\system_widok.tpl',
      1 => 1652771349,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62834a16adb3c2_05788572 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_69878306362834a16adabd7_82354344', 'mid');
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_69878306362834a16adabd7_82354344 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_69878306362834a16adabd7_82354344',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
								<section>
									<h3>Dodawanie Systemu</h3>
								</section>
                                                            <section>
                                                                <div class="row gtr-uniform">
                                                                    <div class="col-12">
                                                                    <input type="text" id="system_nazwa" value="" placeholder="Nazwa systemu" />
                                                                    </div>
                                                                    <li><a href="#dodano_system" class="button primary">Stwórz</a></li>
                                                                </div>
                                                            </section>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
