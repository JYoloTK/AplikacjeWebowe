<?php
/* Smarty version 4.1.0, created on 2022-05-17 09:21:45
  from 'C:\xampp\Nowy folder\htdocs\projekt1\app\views\templates\main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62834d09e9df75_47269263',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '384ff5aad013991c161b9f79c787a8f863c5774b' => 
    array (
      0 => 'C:\\xampp\\Nowy folder\\htdocs\\projekt1\\app\\views\\templates\\main.tpl',
      1 => 1652772103,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62834d09e9df75_47269263 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="pl">

<head>
	<title>Paper RPG</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/assets/css/main.css" />
	<noscript><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
    		<!-- Page Wrapper -->
			<div id="page-wrapper">

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_79243179062834d09e90208_47941031', 'top');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13589995762834d09e92ed5_16231122', 'messages');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_133983856462834d09e9d1d3_70137547', 'mid');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_121618393362834d09e9d9c2_73473562', 'bottom');
?>


</body>

</html><?php }
/* {block 'top'} */
class Block_79243179062834d09e90208_47941031 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_79243179062834d09e90208_47941031',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 
				<!-- Header -->
					<header id="header">
						<h1><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Hello" class="pure-menu-heading pure-menu-link">Paper RPG</a></h1>
						<nav id="nav">
							<ul>
								<li class="special">
									<a href="#menu" class="menuToggle"><span>Menu</span></a>
									<div id="menu">
										<ul>

											<li>Menu</li>
											<li><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
logowanie" class="pure-menu-heading pure-menu-link">Zaloguj się</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
swiat" class="pure-menu-heading pure-menu-link">Stwórz świat</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
postac" class="pure-menu-heading pure-menu-link">Stwórz postać</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lokacja" class="pure-menu-heading pure-menu-link">Stwórz lokacje</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
npc" class="pure-menu-heading pure-menu-link">Stwórz NPC</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
potwor" class="pure-menu-heading pure-menu-link">Stwórz potwora</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
system" class="pure-menu-heading pure-menu-link">Dodaj system</a></li>
                                                                                        <li><a href="#" class="pure-menu-heading pure-menu-link">Wyloguj się</a></li>
                                                                                        
										</ul>
									</div>
								</li>
							</ul>
						</nav>
					</header>
<?php
}
}
/* {/block 'top'} */
/* {block 'messages'} */
class Block_13589995762834d09e92ed5_16231122 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'messages' => 
  array (
    0 => 'Block_13589995762834d09e92ed5_16231122',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>
<section class="wrapper style2">
<div class="inner">
	<ul class="alt">
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
	<li style="color:#ffffa0" class="msg <?php if ($_smarty_tpl->tpl_vars['msg']->value->isError()) {?>error<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isWarning()) {?>warning<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isInfo()) {?>info<?php }?>"><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
	<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	</ul>
</div>
</section>
<?php }?>

<?php
}
}
/* {/block 'messages'} */
/* {block 'mid'} */
class Block_133983856462834d09e9d1d3_70137547 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_133983856462834d09e9d1d3_70137547',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'mid'} */
/* {block 'bottom'} */
class Block_121618393362834d09e9d9c2_73473562 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'bottom' => 
  array (
    0 => 'Block_121618393362834d09e9d9c2_73473562',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Footer -->
					<footer id="footer">
						<ul class="icons">
							<li><a href="#" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
							<li><a href="#" class="icon brands fa-facebook-f"><span class="label">Facebook</span></a></li>
							<li><a href="#" class="icon brands fa-instagram"><span class="label">Instagram</span></a></li>
							<li><a href="#" class="icon brands fa-dribbble"><span class="label">Dribbble</span></a></li>
							<li><a href="#" class="icon solid fa-envelope"><span class="label">Email</span></a></li>
						</ul>
						<ul class="copyright">
							<li>&copy; Untitled</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
						</ul>
					</footer>

			</div>

		<!-- Scripts -->
			<?php echo '<script'; ?>
 src="assets/js/jquery.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/jquery.scrollex.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/jquery.scrolly.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/browser.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/breakpoints.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/util.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/main.js"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'bottom'} */
}
