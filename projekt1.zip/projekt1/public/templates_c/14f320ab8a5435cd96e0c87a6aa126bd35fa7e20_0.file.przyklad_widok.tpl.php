<?php
/* Smarty version 4.1.0, created on 2022-05-16 17:41:17
  from 'C:\xampp\htdocs\projekt1\app\views\przyklad_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6282709db31780_42910266',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '14f320ab8a5435cd96e0c87a6aa126bd35fa7e20' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\przyklad_widok.tpl',
      1 => 1652715675,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6282709db31780_42910266 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19845175526282709db30d37_21226612', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_19845175526282709db30d37_21226612 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_19845175526282709db30d37_21226612',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
								<section>
									<h4>Logowanie</h4>
									<form method="post" action="#">
										<div class="row gtr-uniform">
											<div class="col-6 col-12-xsmall">
												<input type="text" id="id_login" placeholder="Login" />
											</div>
											<div class="col-6 col-12-xsmall">
												<input type="password" id="id_password" placeholder="Hasło" />
											</div>
                                                                                        <div class="actions">
                                                                                            <li><a href="#zaloguj" class="button primary">Zaloguj</a></li>
                                                                                        </div>
										</div>
									</form>
								</section>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
