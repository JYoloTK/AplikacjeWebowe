<?php
/* Smarty version 4.1.0, created on 2022-05-22 15:14:26
  from 'C:\xampp\htdocs\projekt1\app\views\logowanie_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628a373273eae5_51590340',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eaf6f17616de685e746de9b960462c9dc9191e55' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\logowanie_widok.tpl',
      1 => 1652715676,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628a373273eae5_51590340 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2127128541628a373273cb26_76057069', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_2127128541628a373273cb26_76057069 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_2127128541628a373273cb26_76057069',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
								<section>
									<h4>Logowanie</h4>
									<form method="post" action="#">
										<div class="row gtr-uniform">
											<div class="col-6 col-12-xsmall">
												<input type="text" id="id_login" placeholder="Login" />
											</div>
											<div class="col-6 col-12-xsmall">
												<input type="password" id="id_password" placeholder="Hasło" />
											</div>
                                                                                        <div class="actions">
                                                                                            <li><a href="#zaloguj" class="button primary">Zaloguj</a></li>
                                                                                        </div>
										</div>
									</form>
								</section>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
