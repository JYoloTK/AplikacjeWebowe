<?php
/* Smarty version 4.1.0, created on 2022-05-17 08:12:51
  from 'C:\xampp\Nowy folder\htdocs\projekt1\app\views\swiat_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62833ce3e344b4_91983106',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4cc0a40fd22f1deb9c01e8661bd0ed77071b2b17' => 
    array (
      0 => 'C:\\xampp\\Nowy folder\\htdocs\\projekt1\\app\\views\\swiat_widok.tpl',
      1 => 1652711106,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62833ce3e344b4_91983106 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_127984958662833ce3e33906_48194341', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_127984958662833ce3e33906_48194341 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_127984958662833ce3e33906_48194341',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
                                                            <section>
								<h3>Tworzenie Świata</h3>
                                                            </section>
                                                            <section>
                                                                <div class="row gtr-uniform">
                                                                    <div class="col-12">
                                                                    <input type="text" id="swiat_nazwa" value="" placeholder="Nazwa świata" />
                                                                    </div>
                                                                    <div class="col-12">
									<select id="swiat_mechanika">
										<option value="">Wybierz mechanikę</option>
										<option value="1">Mechanika 1</option>
										<option value="1">Mechanika 2</option>
										<option value="1">Mechanika 3</option>
									</select>
                                                                    </div>
                                                                    <li><a href="#stworzono_swiat" class="button primary">Stwórz</a></li>
                                                                </div>
                                                            </section>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
