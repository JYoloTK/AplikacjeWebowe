<?php
/* Smarty version 4.1.0, created on 2022-05-16 17:34:53
  from 'C:\xampp\htdocs\projekt1\app\views\postac_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62826f1dd0ece0_11988458',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '75824cf2977848fd649abafdfbc570eef80f6478' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\postac_widok.tpl',
      1 => 1652715290,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62826f1dd0ece0_11988458 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_53313196562826f1dd0e320_52390339', 'mid');
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_53313196562826f1dd0e320_52390339 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_53313196562826f1dd0e320_52390339',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
                                                            <section>
								<h3>Tworzenie Postaci</h3>
                                                            </section>
                                                            <section>
                                                                <div class="row gtr-uniform">
                                                                    <div class="col-12">
                                                                    <input type="text" id="postac_nazwa" value="" placeholder="Nazwa" />
                                                                    </div>
                                                                    <div class="col-6 col-12-small">
                                                                    <input type="text" id="postac_rasa" value="" placeholder="Rasa" />
                                                                    </div>
                                                                    <div class="col-6 col-12-small">
                                                                    <input type="text" id="postac_klasa" value="" placeholder="Klasa" />
                                                                    </div>
                                                                    <div class="col-12">
                                                                    <input type="text" id="postac_wiek" value="" placeholder="Wiek" />
                                                                    </div>
                                                                    <div class="col-12">
                                                                    <input type="text" id="postac_level" value="" placeholder="Level" />
                                                                    </div>
                                                                    <div class="actions">
                                                                    <li><a href="#stworzono_postac" class="button primary">Stwórz</a></li>
                                                                    </div>
                                                                </div>
                                                            </section>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
