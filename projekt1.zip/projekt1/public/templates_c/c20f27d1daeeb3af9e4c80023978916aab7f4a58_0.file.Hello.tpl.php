<?php
/* Smarty version 4.1.0, created on 2022-05-16 17:40:42
  from 'C:\xampp\htdocs\projekt1\app\views\Hello.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6282707a5aaa21_19927361',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c20f27d1daeeb3af9e4c80023978916aab7f4a58' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\Hello.tpl',
      1 => 1652715627,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6282707a5aaa21_19927361 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8560226546282707a5a6aa9_42553522', 'mid');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_8560226546282707a5a6aa9_42553522 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_8560226546282707a5a6aa9_42553522',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


				<!-- Main -->
					<article id="main">
						<header>
							<h2>Bukszpan</h2>
							<p>kolos srolos</p>
						</header>
						<section class="wrapper style5">
							<div class="inner">
								<h4>Logowanie</h4>
									<form method="post" action="#">
										<div class="row gtr-uniform">
											<div class="col-6 col-12-xsmall">
												<input type="text" id="id_login" value="" placeholder="Login" />
											</div>
											<div class="col-6 col-12-xsmall">
												<input type="password" id="id_password" value="" placeholder="Hasło" />
											</div>
										</div>
                                                                        </form>
							</div>	
						</section>
					</article>

<?php
}
}
/* {/block 'mid'} */
}
