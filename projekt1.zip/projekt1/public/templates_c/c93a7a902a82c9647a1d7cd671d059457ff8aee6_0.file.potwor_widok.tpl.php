<?php
/* Smarty version 4.1.0, created on 2022-05-16 17:22:06
  from 'C:\xampp\htdocs\projekt1\app\views\potwor_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62826c1e93f429_31759386',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c93a7a902a82c9647a1d7cd671d059457ff8aee6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\potwor_widok.tpl',
      1 => 1652714523,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62826c1e93f429_31759386 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_31017190362826c1e93e8d8_84367162', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_31017190362826c1e93e8d8_84367162 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_31017190362826c1e93e8d8_84367162',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
								<section>
									<h3>Tworzenie Potwora</h3>
								</section>
                                                            <section>
                                                                <div class="row gtr-uniform">
                                                                    <div class="col-12">
                                                                    <input type="text" id="potwor_rasa" value="" placeholder="Rasa" />
                                                                    </div>
                                                                    <li><a href="#stworzono_swiat" class="button primary">Stwórz</a></li>
                                                                </div>
                                                            </section>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
