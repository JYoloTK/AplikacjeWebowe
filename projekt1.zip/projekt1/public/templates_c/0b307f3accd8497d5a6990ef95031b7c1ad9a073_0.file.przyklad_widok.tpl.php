<?php
/* Smarty version 4.1.0, created on 2022-05-17 08:10:44
  from 'C:\xampp\Nowy folder\htdocs\projekt1\app\views\przyklad_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62833c64e34266_62034084',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0b307f3accd8497d5a6990ef95031b7c1ad9a073' => 
    array (
      0 => 'C:\\xampp\\Nowy folder\\htdocs\\projekt1\\app\\views\\przyklad_widok.tpl',
      1 => 1652715676,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62833c64e34266_62034084 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_155759216462833c64e334e9_13967390', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_155759216462833c64e334e9_13967390 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_155759216462833c64e334e9_13967390',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
								<section>
									<h4>Logowanie</h4>
									<form method="post" action="#">
										<div class="row gtr-uniform">
											<div class="col-6 col-12-xsmall">
												<input type="text" id="id_login" placeholder="Login" />
											</div>
											<div class="col-6 col-12-xsmall">
												<input type="password" id="id_password" placeholder="Hasło" />
											</div>
                                                                                        <div class="actions">
                                                                                            <li><a href="#zaloguj" class="button primary">Zaloguj</a></li>
                                                                                        </div>
										</div>
									</form>
								</section>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
