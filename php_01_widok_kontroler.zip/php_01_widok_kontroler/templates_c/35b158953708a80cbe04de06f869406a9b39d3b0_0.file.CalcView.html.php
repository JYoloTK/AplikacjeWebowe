<?php
/* Smarty version 4.1.0, created on 2022-04-04 21:54:04
  from 'C:\xampp\htdocs\php_01_widok_kontroler\app\calc\CalcView.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_624b4cdc33e4a0_54379610',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '35b158953708a80cbe04de06f869406a9b39d3b0' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_01_widok_kontroler\\app\\calc\\CalcView.html',
      1 => 1649102039,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_624b4cdc33e4a0_54379610 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1233487920624b4cdc2e0b55_52370127', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ($_smarty_tpl->tpl_vars['conf']->value->root_path).("/templates/main.html"));
}
/* {block 'content'} */
class Block_1233487920624b4cdc2e0b55_52370127 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1233487920624b4cdc2e0b55_52370127',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>



				<!-- Main -->
					<article id="main">
<!--                                            <div class="col-6 col-12-medium">
                                                <ul class="actions">
							<li><a href="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
/app/security/logout.php" class="button">Wyloguj</a></li>
						</ul>
                                            </div>-->
						<header>
							<h2>Kalkulator kredytowy</h2>
							<p>Oblicz swoje życie</p>
						</header>
						<section class="wrapper style5">
							<div class="inner">

								<section>
									<h4>Wpisz wartości:</h4>
									<form method="post" action="#">
                                        <div class="row gtr-uniform">
                                            <div class="col-4 col-12-xsmall">
                                                <input type="text" name="x" id="id_x" placeholder="Kwota" />
                                            </div>
                                            <div class="col-4 col-12-xsmall">
                                                <input type="text" name="y" id="id_y" placeholder="Ilość miesięcy" />
                                            </div>
                                            <div class="col-4 col-12-xsmall">
                                                <input type="text" name="z" id="id_z" placeholder="Oprocentowanie" />
                                            </div>

                                            <div class="col-12">
                                                <ul class="actions">
                                                    <li><input type="submit" value="Oblicz" class="primary" /></li>
                                                </ul>
                                            </div>
                                        </div>
									</form>
								</section>

							</div>
						</section>
					</article>
                                
<div class="messages">

<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
	<h4>Wystąpiły błędy: </h4>
	<ol class="err">
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getErrors(), 'err');
$_smarty_tpl->tpl_vars['err']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['err']->value) {
$_smarty_tpl->tpl_vars['err']->do_else = false;
?>
	<li><?php echo $_smarty_tpl->tpl_vars['err']->value;?>
</li>
	<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	</ol>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isInfo()) {?>
	<h4>Informacje: </h4>
	<ol class="inf">
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getInfos(), 'inf');
$_smarty_tpl->tpl_vars['inf']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['inf']->value) {
$_smarty_tpl->tpl_vars['inf']->do_else = false;
?>
	<li><?php echo $_smarty_tpl->tpl_vars['inf']->value;?>
</li>
	<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	</ol>
<?php }?>

<?php if ((isset($_smarty_tpl->tpl_vars['res']->value->result))) {?>
	<h4>Wynik</h4>
	<p class="res">
	<?php echo $_smarty_tpl->tpl_vars['res']->value->result;?>

	</p>
<?php }?>

</div>

<?php
}
}
/* {/block 'content'} */
}
