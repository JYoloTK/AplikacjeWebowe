<?php
/* Smarty version 4.1.0, created on 2022-04-04 14:13:07
  from 'C:\xampp\htdocs\php_01_widok_kontroler\app\calc.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_624ae0d33ca235_47767754',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '321c6d8e86cad16731daf8400673b5d7ccc8f632' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_01_widok_kontroler\\app\\calc.html',
      1 => 1649074382,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_624ae0d33ca235_47767754 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_66123484624ae0d32d43b8_26503016', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "../templates/main.html");
}
/* {block 'content'} */
class Block_66123484624ae0d32d43b8_26503016 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_66123484624ae0d32d43b8_26503016',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>



				<!-- Main -->
					<article id="main">
                                            <div class="col-6 col-12-medium">
                                                <ul class="actions">
							<li><a href="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
/app/security/logout.php" class="button">Wyloguj</a></li>
						</ul>
                                            </div>
						<header>
							<h2>Kalkulator kredytowy</h2>
							<p>Oblicz swoje życie</p>
						</header>
						<section class="wrapper style5">
							<div class="inner">

								<section>
									<h4>Wpisz wartości:</h4>
									<form method="post" action="#">
                                        <div class="row gtr-uniform">
                                            <div class="col-4 col-12-xsmall">
                                                <input type="text" name="x" id="id_x" placeholder="Kwota" />
                                            </div>
                                            <div class="col-4 col-12-xsmall">
                                                <input type="text" name="y" id="id_y" placeholder="Ilość miesięcy" />
                                            </div>
                                            <div class="col-4 col-12-xsmall">
                                                <input type="text" name="z" id="id_z" placeholder="Oprocentowanie" />
                                            </div>

                                            <div class="col-12">
                                                <ul class="actions">
                                                    <li><input type="submit" value="Oblicz" class="primary" /></li>
                                                </ul>
                                            </div>
                                        </div>
									</form>
								</section>

							</div>
						</section>
					</article>
                                


<div class="messages">

<?php if ((isset($_smarty_tpl->tpl_vars['messages']->value))) {?>
	<?php if (count($_smarty_tpl->tpl_vars['messages']->value) > 0) {?> 
		<h4>Wystąpiły błędy: </h4>
		<ol class="err">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['messages']->value, 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
		<li><?php echo $_smarty_tpl->tpl_vars['msg']->value;?>
</li>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ol>
	<?php }
}?>

<?php if ((isset($_smarty_tpl->tpl_vars['infos']->value))) {?>
	<?php if (count($_smarty_tpl->tpl_vars['infos']->value) > 0) {?> 
		<h4>Informacje: </h4>
		<ol class="inf">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['infos']->value, 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
		<li><?php echo $_smarty_tpl->tpl_vars['msg']->value;?>
</li>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ol>
	<?php }
}?>

<?php if ((isset($_smarty_tpl->tpl_vars['result']->value))) {?>
	<h4>Wynik</h4>
	<p class="res">
	<?php echo $_smarty_tpl->tpl_vars['result']->value;?>

	</p>
<?php }?> 

</div>

<?php
}
}
/* {/block 'content'} */
}
